/*
 * Alyssa Gao
 * Monster Hunter Mini-World Assignment
 * User inputs a maze file, and the program outputs the total traps placed, the minimum number of traps placed, the maximum number of steps taken by the monster before it is caught, and the minimum number of steps taken in between traps 
 * April 15, 2018
 */

import java.io.File;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Scanner;

public class MonsterHunterMiniWorld{
  
  /**
   * Main container that stores the maze data in a 2D array.
   */
  static char[][] mazeData;
  
  /**
   * A tracker maze (breadcrumbs)
   */
  static char[][] trackMazeData;
  
  /**
   * Enumeration of moving directions used when navigating through maze
   */
  static int UP = 1, DOWN = 2, LEFT = 3, RIGHT = 4;
  
  /**
   * To keep which traps are on the current path each time when Food is reached
   */
  static String trapInfo = "";
  
  /**
   * To keep all trapInfo for each path accumulatively.
   */
  static String pathInfo = "";
  
  /**
   * The pointer/index of current path when recording the pathInfo
   */
  static int pathIndex = 0;
  
  /**
   * This is used to output all the steps taken in between traps (Level 4++)
   */
  static String minTotalStepsOfTrapCombinationResult = "";
  
  /**
   * Used to output to "solution.txt"
   */
  static PrintWriter printWriter;
  
  /**
   * main
   * Main method that completes all levels.
   * @param args This is not required and used for this program. 
   * @throws Exception any errors that may occur in the program.
   */
  public static void main(String[] args) throws Exception {
   
    // declare/initialize variables
    Scanner scanner = new Scanner(System.in); // used for user input
    File outputFile = new File("solution.txt"); // the file where the results will be output to
    printWriter = new PrintWriter(outputFile); // used to output to text file
    int totalTrapCount = 0; // used to consolidate file
    String pathInfoCopy = ""; // this will be used to copy all the paths we generated from Level 3
    int pathDelimiterPosition; // position that will be used to separate paths in pathInfoCopy 
    int totalMinTraps = 0; // total minimum traps (used in Level 4)
    int minTrapIndex = 0;  // keep track of minimum trap's position in array (Level 4)
    String firstTrapOnEachPath = ""; // statement that will be outputted later for worst case scenario trap (Level 4+)
    int maxStepsToFirstMinTrap = -1; // keep track of maximum steps taken to reach first trap for worst case scenario (Level 4+) based on Level 4 traps

    int[][] minTraps; // store all the minimum traps (for Level 4++)

    
    // asking for file name (the file in which the maze is stored in)
    System.out.print ( "Please enter the name of the maze file: " );
    String fileName = scanner.nextLine();
    
    // output to screen
    System.out.println("The result will be outputted to the \"" + outputFile.getAbsolutePath() + "\" file.");
    
    mazeData = readMazeFile(fileName); // copy the maze file into a char[][] array
    
    // ---------------------------------------------------------
    // Level 3 - Sets all traps along monster's path
    // ---------------------------------------------------------
    outputln("***************************************** MONSTER HUNTER SOLUTION ***************************************** ");
    outputln("\n-------------- LEVEL 3 --------------");
    outputln("-- SETS ALL TRAPS ALONG MONSTER'S PATH --");
    
    initializeMazeDataTrack();
    solveMaze(1, 0, 1, 0, 0); // navigates through maze (finds all paths and trap on paths)
    
    outputMaze(mazeData); // outputs maze with all traps on possible paths changed from 'P' to 'T'
    outputln("");
    
    pathInfoCopy = pathInfo; // make a copy of the path information so we don't lose it
    pathDelimiterPosition = pathInfoCopy.indexOf("\n"); 
    
    int[][] effectiveTraps = new int[mazeData.length * mazeData[0].length][4]; // used to store all the traps found in Level 3
    // effectiveTrap[x][0] - row(or x) of the trap
    // effectiveTrap[x][1] - column (or y) of the trap, 
    // effectiveTrap[x][2] - max steps to reach the trap from N
    // effectiveTrap[x][3] - '0' (default value) means this is not a Level 4 trap // '1' means it is a Level 4 trap.  
    
    // Consolidate Trap Info data.
    //takes each trap's row number, column number and number of steps to reach the trap from the pathInfoCopy string
    while (pathDelimiterPosition >= 0) {
      String pathItem = pathInfoCopy.substring(0, pathDelimiterPosition);
      String trapForCurrentPath = pathItem.substring(pathItem.indexOf(":") + 1);
      int trapDelimiterPosition = trapForCurrentPath.indexOf("#");
      while (trapDelimiterPosition >= 0) {
        String trapItem = trapForCurrentPath.substring(1, trapDelimiterPosition); // takes the three numbers between the '$' and the '#' [$row#, col#, (numOfSteps)#]
        int coordinateDelimiterPosition = trapItem.indexOf(",");
        int numOfStepsPosition = trapItem.indexOf("(");
        int rowNum = Integer.parseInt(trapItem.substring(0, coordinateDelimiterPosition));
        int colNum = Integer.parseInt(trapItem.substring(coordinateDelimiterPosition + 1, numOfStepsPosition));
        int numofStepsReachingTrap = Integer.parseInt(trapItem.substring(numOfStepsPosition + 1, trapItem.length() - 1));
        
        // try to find if (rowNum,colNum) is already in effectiveTraps[][]
        // add the trap to effectiveTraps[][] if it is not already there.
        boolean foundTrap = false;
        for (int i = 0; i < totalTrapCount && !foundTrap; i++) {
          if ((effectiveTraps[i][0] == rowNum) && (effectiveTraps[i][1] == colNum)) {
            foundTrap = true;
            effectiveTraps[i][2] = Integer.max(effectiveTraps[i][2], numofStepsReachingTrap);
          }
        }
        if (!foundTrap) {
          effectiveTraps[totalTrapCount][0] = rowNum;
          effectiveTraps[totalTrapCount][1] = colNum;
          effectiveTraps[totalTrapCount][2] = numofStepsReachingTrap;
          totalTrapCount++;
        }
        trapForCurrentPath = trapForCurrentPath.substring(trapDelimiterPosition + 1);
        trapDelimiterPosition = trapForCurrentPath.indexOf("#");
      }
      pathInfoCopy = pathInfoCopy.substring(pathDelimiterPosition + 1);
      pathDelimiterPosition = pathInfoCopy.indexOf("\n");
    }
    
    effectiveTraps = Arrays.copyOf(effectiveTraps, totalTrapCount); // 2D array is copied so we can reuse it later and not lose the data
    
    outputln ( "All traps along monster's path (level 3):" );
    for ( int i = 0; i < effectiveTraps.length; i ++ ) {
      outputln ( "Trap (" + effectiveTraps[i][0] + ", " + effectiveTraps[i][1] + ")" ); // outputs all trap coordinates
    }
    
    // ---------------------------------------------------------
    // Level 4 - Figure out the minimum number of traps 
    // ---------------------------------------------------------
    
    outputln("\n\n\n-------------- Level 4 --------------");
    outputln("---------- MINIMUM NUMBER OF TRAPS ----------");
    
    // The findMinimumNumberOfTraps() is to find the minimum number of traps for Level 4.
    findMinimumNumberOfTraps(effectiveTraps);
    
    // The following code does two things: 
    // 1. Iterate the effectiveTraps and populate a new traps array for minimum traps; 
    // 2. Ouputs the mininum traps.
    outputln ( "\nMinimum number of traps to guarantee the monsters capture: " );
    
    for ( int i = 0; i < effectiveTraps.length; i ++ ) { 
      if ( effectiveTraps[i][3] == 1 ) {
        totalMinTraps ++; 
      }
    }
    minTraps = new int[totalMinTraps][2];
    for ( int i = 0; i < effectiveTraps.length; i ++ ) {
      if ( effectiveTraps[i][3] == 1 ) {
        minTraps[minTrapIndex][0] = effectiveTraps[i][0];
        minTraps[minTrapIndex][1] = effectiveTraps[i][1];
        outputln ( "Trap (" + minTraps[minTrapIndex][0] + ", " + minTraps[minTrapIndex][1] + ")" ); // output all minimum traps to text file
        minTrapIndex ++;
      }
    }
    
    // --------------------------------------------
    // LEVEL 4+ - maximum number of steps to get to farthest trap
    // --------------------------------------------
    outputln ( "\n\n\n----------------- Level 4+ ------------------" );
    outputln("-------------- FARTHEST 1st TRAP (based on the Level 4 traps) --------------");
    
    pathInfoCopy = pathInfo;
    pathDelimiterPosition = pathInfoCopy.indexOf("\n");
    while (pathDelimiterPosition >= 0) {
      String pathItem = pathInfoCopy.substring(0, pathDelimiterPosition);
      
      // to find the worse case trap, it must be the first trap on each possible path
      // because this is based on minimumn traps, when looking through each path we will ignore non-minimum traps until we hit the first minimum trap on the path
      // the number of steps it takes to reach that trap was recored beside each trap coordinate --> $rownum,columnNum(number of steps)#
      
      // find the first trap on current path
      int trapPosition = Integer.MAX_VALUE;
      for ( int k = 0; k < minTraps.length; k ++ ) {
        int position = pathItem.indexOf( "$" + minTraps[k][0] + "," + minTraps[k][1] + "(" );
        if ( position >= 0 ) {
          trapPosition = Integer.min(trapPosition, position);
        }
      }
      if ( trapPosition >= 0 ) {
        int positionBegin = pathItem.indexOf( "(", trapPosition);
        int positionEnd = pathItem.indexOf( ")", trapPosition);
        int stepsToReachTheTrap = Integer.parseInt ( pathItem.substring(positionBegin+1, positionEnd ) );
         
        // if the number of steps used is bigger than current maxStepsToFirstMinTrap, the number of steps taken will replace it the current maximum number
        if ( maxStepsToFirstMinTrap < stepsToReachTheTrap ) {
          maxStepsToFirstMinTrap = stepsToReachTheTrap;
          firstTrapOnEachPath = " at Trap(" + pathItem.substring(trapPosition+1, positionBegin) + ")";
        } else if ( maxStepsToFirstMinTrap == stepsToReachTheTrap ) {
          if ( firstTrapOnEachPath.indexOf( "Trap(" + pathItem.substring(trapPosition+1, positionBegin) + ")" ) < 0 ) {
            firstTrapOnEachPath += " or Trap(" + pathItem.substring(trapPosition+1, positionBegin) + ")";
          }
        }
        maxStepsToFirstMinTrap = Integer.max(stepsToReachTheTrap, maxStepsToFirstMinTrap);
      }
      pathInfoCopy = pathInfoCopy.substring(pathDelimiterPosition + 1); // continue to check for remaining paths (if possible)
      pathDelimiterPosition = pathInfoCopy.indexOf("\n");
    }
    outputln ( "The worst case scenario for the (max) number of steps the monster takes until capture: " + maxStepsToFirstMinTrap + firstTrapOnEachPath );
    
    // --------------------------------------------
    // Level 4++ (based on Level 4 traps)
    // --------------------------------------------
    outputln ( "\n\n\n----------------- Level 4++ (based on Level 4 traps)------------------" );
    findDistanceBetweenTraps ( minTraps );
    
    // Close I/O 
    scanner.close();
    printWriter.close();
  }
// --------------------------------------- END OF MAIN METHOD ---------------------------------------
  
  
  // --------------------------------------- METHODS ---------------------------------------
  
  /**
   * solveMaze
   * Travels through the maze from one cell to adjacent cells recursively whenever there is a path.
   * @param originalRow the row number for the cell it moves from.
   * @param originalColumn the column number for the cell it moves from.
   * @param currentRow the row number for the cell it is going to
   * @param currentColumn the column number for the cell it is going 
   * @param numOfStepsReachHere the int that stores the number of steps it takes to reach the current cell.
   * @return boolean, true if the 'F' (Food) is reached.
   */
  public static boolean solveMaze(int originalRow, int originalColumn, int currentRow, int currentColumn, int numOfStepsReachHere) {
    
    int fromDirection = 0;
    boolean foundFood = false;
      
    // replaces 'F' with space in tracker maze
    if (mazeData[currentRow][currentColumn] == 'F') {
      trackMazeData[currentRow][currentColumn] = ' ';
      pathInfo += ("PATH" + pathIndex++ + ":" + trapInfo + "\n");
      return true;
    } else {
      trackMazeData[currentRow][currentColumn] = 'X'; // replaces empty space with 'X' to mark that we have travelled here
      if ((mazeData[currentRow][currentColumn] == 'P') || (mazeData[currentRow][currentColumn] == 'T')) {
        trapInfo += ("$" + currentRow + "," + currentColumn + "(" + numOfStepsReachHere + ")#"); // adds trap to list of traps and steps taken to hit the trap
      }
      
      // Figuring out direction it came from (fromDirection)
      //   originalX == currentX:
      //   currentY < originalY: RIGHT
      //   currentY > originalY: LEFT
      //   originalY == currentY:
      //   currentX < originalX: UP
      //   currentY > originalY: DOWN
      
      // UP = 1, DOWN = 2, LEFT = 3, RIGHT = 4 (this was initialized above      
      // Starting point (N)
      fromDirection = LEFT;
      if ((originalRow == currentRow) && (originalColumn == currentColumn) && (originalRow == 1) && (originalColumn == 0)) { 
      } else {
        if (originalRow == currentRow) {
          if (currentColumn > originalColumn) {
            fromDirection = LEFT;
          } else {
            fromDirection = RIGHT;
          }
        } else if (originalColumn == currentColumn) {
          if (currentRow > originalRow) {
            fromDirection = UP;
          } else {
            fromDirection = DOWN;
          }
        }
      }
      
      // Try UP direction
      if (fromDirection != UP) {
        if ((trackMazeData[currentRow - 1][currentColumn] == ' ') || (mazeData[currentRow - 1][currentColumn] == 'F')) {
          // It can move UP
          if (solveMaze(currentRow, currentColumn, currentRow - 1, currentColumn, numOfStepsReachHere + 1) ) { 
            foundFood = true; // the current step is the correct step as it is on a path that will lead to 'F'
          }
        }
      }
      
      // Try DOWN direction
      if (fromDirection != DOWN) {
        if ((trackMazeData[currentRow + 1][currentColumn] == ' ') || (mazeData[currentRow + 1][currentColumn] == 'F')) {
          // It can move DOWN
          if (solveMaze(currentRow, currentColumn, currentRow + 1, currentColumn, numOfStepsReachHere + 1) ) {
            foundFood = true; // the current step is the correct step as it is on a path that will lead to 'F'
          }
        }
      }
      
      // Try LEFT direction
      if (fromDirection != LEFT) {
        if ((trackMazeData[currentRow][currentColumn - 1] == ' ') || (mazeData[currentRow][currentColumn - 1] == 'F')) {
          // It can move LEFT
          if (solveMaze(currentRow, currentColumn, currentRow, currentColumn - 1, numOfStepsReachHere + 1) ) {
            foundFood = true; // the current step is the correct step as it is on a path that will lead to 'F'
          }
        }
      }
      
      // Try RIGHT direction
      if (fromDirection != RIGHT) {
        if ((trackMazeData[currentRow][currentColumn + 1] == ' ') || (mazeData[currentRow][currentColumn + 1] == 'F')) {
          // It can move RIGHT
          if ( solveMaze(currentRow, currentColumn, currentRow, currentColumn + 1, numOfStepsReachHere + 1) ) {
            foundFood = true; // the current step is the correct step as it is on a path that will lead to 'F'
          }
        }
      }
      
      // replace P's with T as long as the P's are found on paths that will lead to 'F'
      if ((mazeData[currentRow][currentColumn] == 'P') && (foundFood)) {
        mazeData[currentRow][currentColumn] = 'T'; 
      }
      
      // remove traps that don't work from the list of traps (eg. traps that are on a path that lead to a dead end)
      trackMazeData[currentRow][currentColumn] = ' ';
      if ((mazeData[currentRow][currentColumn] == 'P') || (mazeData[currentRow][currentColumn] == 'T')) {
        int lastTrapCoordinatePosition = trapInfo.lastIndexOf("$");
        if (lastTrapCoordinatePosition >= 0) {
          trapInfo = trapInfo.substring(0, lastTrapCoordinatePosition);
        }
      }
      return foundFood;
    }
  }
  
  /**
   * initializeMazeDataTrack
   * Make a replicate copy of mazeData and then replace P, T with blank space, and replace all others with '*' representing the walls.
   * This will be used as a working copy of the mazeData when travels within the maze.
   */ 
  public static void initializeMazeDataTrack() {
    
    // Initialize maze tracker
    trackMazeData = new char[mazeData.length][mazeData[0].length];
    for (int i = 0; i < mazeData.length; i++) {
      for (int j = 0; j < mazeData[0].length; j++) {
        if ((mazeData[i][j] == ' ') || (mazeData[i][j] == 'P') || (mazeData[i][j] == 'T')) {
          trackMazeData[i][j] = ' ';
        } else {
          trackMazeData[i][j] = '*';
        }
      }
    }
  }
  
  /**
   * findMinimumNumberOfTraps
   * Find the minimum number of traps based on the effectiveTraps that were identified during Level 3 (Used for Level 4).
   * @param effectiveTraps all effective/eligible traps that were identified at Level 3.
   */
  public static void findMinimumNumberOfTraps ( int[][] effectiveTraps ) {
    
    // The loop is to find all unique combinations of identified traps.
    // It starts with the combination size of 1 and increased subsequently until the first combination is found that covers all paths.
    // For example, combinations for three traps (trap1, trap2, trap3) will be:
    //   (trap1), (trap2), (trap3), (trap1, trap2), (trap1, trap3), (trap2, trap3), (trap1, trap2, trap3)
    // Each iteration of the for loop is to find a combination of a specified combinationLength, staring at 1.
    for (int i = 0; i < effectiveTraps.length; i++) {
      int combinationLength = i + 1;
      int[] trapIndexCombination = new int[combinationLength];
      if ( completeTrapCombination(effectiveTraps, trapIndexCombination, 0, combinationLength, 0 ) ) {
        return;
      }
    }
  }
  
  /**
   * completeTrapCombination
   * Find all unique trap combinations with specified combinationLength.
   * For each combination, traps in the combination will be set as a wall (using '*' character) 
   * Then maze is tested to see if 'F' can be reached. 
   * If not, the combination is the one we're looking for (returns true). 
   * Otherwise, it keeps looking for the remaining combinations, until all combinations are exhausted (returns false). 
   * @param effectiveTraps all effective/eligible traps that were identified at Level 3.
   * @param trapIndexCombination the array for the combination that contains the trap index/position in the identified trap array.
   * @param combinationIndex the index of the combination the current recursion populates 
   * @param combinationLength the size (the number of traps) of the combination
   * @param startTrapIndex the index of the trap in identified trap array that the current recursion looks for while filling the combination.
   * @return boolean, true if the trap combination is the essential traps that guarantee the monsters capture.
   */
  public static boolean completeTrapCombination(int[][] effectiveTraps, int[] trapIndexCombination, int combinationIndex, int combinationLength, int startTrapIndex ) {
   
 boolean foundPath = false;
 
    if (combinationIndex == combinationLength) {
      // copy maze to backupMaze, replace all Ts that are in trapIndexCombination array with '*'
      // then call solveMaze(), if returns false, then we found the minimum number of traps , so returns true to indicate findMinimumNumberOfTraps() to stop.
      char[][] backupMaze = copyMaze(mazeData);
      initializeMazeDataTrack();
      
      for (int k = 0; k < trapIndexCombination.length; k++) {
        mazeData[effectiveTraps[trapIndexCombination[k]][0]][effectiveTraps[trapIndexCombination[k]][1]] = '*';
        trackMazeData[effectiveTraps[trapIndexCombination[k]][0]][effectiveTraps[trapIndexCombination[k]][1]] = '*';
      }
      
      foundPath = solveMaze(1, 0, 1, 0, 0);
      
      if (!foundPath) {
        mazeData = copyMaze(backupMaze);
        for (int i = 0; i < mazeData.length; i++) {
          for (int j = 0; j < mazeData[0].length; j++) {
            if (mazeData[i][j] == 'T') {
              boolean inMinimumTrapGroup = false;
              for (int k = 0; k < trapIndexCombination.length && !inMinimumTrapGroup; k++) {
                if ((effectiveTraps[trapIndexCombination[k]][0] == i) && (effectiveTraps[trapIndexCombination[k]][1] == j)) {
                  effectiveTraps[trapIndexCombination[k]][3] = 1; // marks the trap as a minimum trap
                  inMinimumTrapGroup = true;
                }
              }
              if (!inMinimumTrapGroup) {
                mazeData[i][j] = 'P';
              }
            }
          }
        }
        outputMaze ( mazeData );
      }
      
      mazeData = copyMaze(backupMaze); // original maze is restored
      
      return !foundPath;
    }
    
    for (int k = startTrapIndex; k < effectiveTraps.length; k++) {
      trapIndexCombination[combinationIndex] = k;
      if ( completeTrapCombination(effectiveTraps, trapIndexCombination,combinationIndex + 1, combinationLength, k + 1 ) ) {
        return true;
      }
    }
    return false;
  }
  
  /**
   * findDistanceBetweenTraps
   * Find distances between traps as well finding total minimum distances between all traps (Level 4++)
   * @param baseTraps the 2D array that has all the trap information
   */
  public static void findDistanceBetweenTraps ( int[][] baseTraps ) {
    int[][] distanceBetweenTrapsMatrix = new int[baseTraps.length][baseTraps.length]; // used to store each individual distance between every two traps
    int minTotalStepsOfTrapCombniation = Integer.MAX_VALUE;
    int[] trapIndexes; // for storing the indexes of all traps that will be used for generating trap combinations.
    
    for (int i = 0; i < baseTraps.length - 1; i++) {
      for (int j = i + 1; j < baseTraps.length; j++) {
        int findDistanceBetweenTraps = calculateDistance(baseTraps[i][0], baseTraps[i][1], baseTraps[j][0], baseTraps[j][1]);
        distanceBetweenTrapsMatrix[i][j] = findDistanceBetweenTraps;
        distanceBetweenTrapsMatrix[j][i] = findDistanceBetweenTraps;
      }
    }
    
    // Make an array of trap indexes (assigning each trap a position/index number)
    // This will be used in making all possible combinations
    trapIndexes = new int[baseTraps.length];
    for (int k = 0; k < baseTraps.length; k++) {
      trapIndexes[k] = k;
    }
    
    minTotalStepsOfTrapCombniation = findTrapComboHavingMinTotalDistrance(baseTraps, distanceBetweenTrapsMatrix, trapIndexes, 0, minTotalStepsOfTrapCombniation);
    outputln ( minTotalStepsOfTrapCombinationResult );
  }
  
  /**
   * findTrapComboHavingMinTotalDistrance
   * Find all combinations for traps and calculate/return the combination with minimum total steps to travel through (Used for Level 4++)
   * @param baseTraps minimum traps found from Level 4
   * @param distanceBetweenTrapsMatrix the matrix that stores all findDistanceBetweenTrapsances/steps between each pair of traps.
   * @param trapIndexes trap combination, used for recursively building the trap combination. Each element is the index of trap within the base trap array.
   * @param trapIndex the index for building the combination recursively.
   * @param minTotalStepsOfTrapCombniation: the so-far calculated minimum total steps to travel through all traps within the current combination.
   * @return int, the minimum total steps to travel through all traps within the current combination. It is for either bringing into the next recursion or returning back to the invoking method (findDistanceBetweenTraps())
   */
  public static int findTrapComboHavingMinTotalDistrance(int[][] baseTraps, int[][] distanceBetweenTrapsMatrix, int[] trapIndexes, int trapIndex, int minTotalStepsOfTrapCombniation) {
    if (trapIndex == trapIndexes.length) {
      int tempTotalSteps = 0;
      String infoOfTraps = "\n\tTrap(" + baseTraps[trapIndexes[0]][0] + ", " + baseTraps[trapIndexes[0]][1] + ")";
      for (int k = 1; k < trapIndexes.length; k++) {
        tempTotalSteps += distanceBetweenTrapsMatrix[trapIndexes[k - 1]][trapIndexes[k]];
        infoOfTraps += (" -- " + distanceBetweenTrapsMatrix[trapIndexes[k - 1]][trapIndexes[k]] + " steps -> Trap(" + baseTraps[trapIndexes[k]][0] + ", " + baseTraps[trapIndexes[k]][1] + ")");
      }
      if (tempTotalSteps < minTotalStepsOfTrapCombniation) {
        minTotalStepsOfTrapCombniation = tempTotalSteps;
        minTotalStepsOfTrapCombinationResult = "Total minimum steps to take to lay down all the traps: " + tempTotalSteps + "\nShortest Path(s):" + infoOfTraps;
      } else if (tempTotalSteps == minTotalStepsOfTrapCombniation) {
        minTotalStepsOfTrapCombinationResult += infoOfTraps;
      }
      
    } else {
      for (int i = trapIndex; i < trapIndexes.length; i++) {
        swapTraps(trapIndexes, trapIndex, i);
        
        minTotalStepsOfTrapCombniation = findTrapComboHavingMinTotalDistrance(baseTraps, distanceBetweenTrapsMatrix, trapIndexes, trapIndex + 1, minTotalStepsOfTrapCombniation);
        
        swapTraps(trapIndexes, i, trapIndex);
      }
    }
    return minTotalStepsOfTrapCombniation;
  }
  
  /**
   * swapTraps
   * This method is used when forming the combinations (used for Level 4++)
   * Each combination is the same length (total number of traps) and the way to find new combos will be through swapping the trap indexes in the combinations
   * @param trapIndexes array of trap indexes
   * @param trapIndex1 trap index for one of the traps
   * @param trapIndex2 trap index for another trap
   */
  public static void swapTraps(int[] trapIndexes, int trapIndex1, int trapIndex2) {
    int temp = trapIndexes[trapIndex1];
    trapIndexes[trapIndex1] = trapIndexes[trapIndex2];
    trapIndexes[trapIndex2] = temp;
  }
  
  /**
   * calculateDistance
   * Calculate the findDistanceBetweenTrapsance between trap(fromRow, fromCol) and trap(toRow, toCol) -- used for Level 4++
   * @param fromRow the row number of the trap it came from
   * @param fromCol the column number of the trap it came from
   * @param toRow the row number of the trap it is going to
   * @param toCol the column number of the trap it is going to
   * @return int, total value of the distance between the two traps
   */
  public static int calculateDistance(int fromRow, int fromCol, int toRow, int toCol) {
    
    int minStepsBetweenCurrentTwoTraps; //used to store the minimum steps between the current trap pair that is returned from calculateDistanceWhenMovingInMaze() method temporarily before return.
    char[][] backupMaze = copyMaze(mazeData);
    
    // Replace Food with wall (using '*'), replace the Trap (toRow, toCol) with 'F'
    boolean foundFood = false;
    for (int i = 0; i < mazeData.length && !foundFood; i++) {
      for (int j = 0; j < mazeData[i].length && !foundFood; j++) {
        if (mazeData[i][j] == 'F') {
          mazeData[i][j] = '*';
          foundFood = true;
        }
      }
    }
    mazeData[toRow][toCol] = 'F';
    initializeMazeDataTrack();
    
    minStepsBetweenCurrentTwoTraps = calculateDistanceWhenMovingInMaze(fromRow, fromCol, fromRow, fromCol, 0, Integer.MAX_VALUE);
    mazeData = copyMaze(backupMaze);
    
    return minStepsBetweenCurrentTwoTraps;
  }
  
  /**
   * calculateDistanceWhenMovingInMaze
   * This is the method that is invoked by the calculateDistance() method for recursively calculating the minimum steps between the 'From' trap and 'Target' trap.
   * It calculates when moving in the maze from the it came from (the From trap) to the "F" (set for the Target trap). (Level 4++)
   * @param originalRow the row number for the cell it moves from.
   * @param originalColumn the column number for the cell it moves from.
   * @param currentRow the row number for the cell it is going to
   * @param currentColumn the column number for the cell it is going 
   * @param numOfStepsReachHere the int that stores the number of steps it takes to reach the current cell.
   * @param minStepsReachHere the minimum number of steps taken to reach current position
   * @return int, the minimum steps to hit 'F' (Target Trap)
   */
  public static int calculateDistanceWhenMovingInMaze(int originalRow, int originalColumn, int currentRow, int currentColumn, int numOfStepsReachHere, int minStepsReachHere) {
    
    int fromDirection = 0;
    if (mazeData[currentRow][currentColumn] == 'F') {
      trackMazeData[currentRow][currentColumn] = ' ';
      minStepsReachHere = Integer.min(minStepsReachHere, numOfStepsReachHere);
      return minStepsReachHere;
    } else {
      
      trackMazeData[currentRow][currentColumn] = 'X';
      
      // Figuring out the fromDirection
      //   originalX == currentX:
      //   currentY < originalY: RIGHT
      //   currentY > originalY: LEFT
      //   originalY == currentY:
      //   currentX < originalX: UP
      //   currentY > originalY: DOWN
      if ((originalRow == currentRow) && (originalColumn == currentColumn)) {
        fromDirection = LEFT;
      } else {
        if (originalRow == currentRow) {
          if (currentColumn > originalColumn) {
            fromDirection = LEFT;
          } else {
            fromDirection = RIGHT;
          }
        } else if (originalColumn == currentColumn) {
          if (currentRow > originalRow) {
            fromDirection = UP;
          } else {
            fromDirection = DOWN;
          }
        }
      }
      
      // Try UP direction
      if (fromDirection != UP) {
        if ((trackMazeData[currentRow - 1][currentColumn] == ' ') || (mazeData[currentRow - 1][currentColumn] == 'F')) {
          // It can move UP
          minStepsReachHere = calculateDistanceWhenMovingInMaze(currentRow, currentColumn, currentRow - 1, currentColumn, numOfStepsReachHere + 1, minStepsReachHere);
        }
      }
      
      // Try DOWN direction
      if (fromDirection != DOWN) {
        if ((trackMazeData[currentRow + 1][currentColumn] == ' ') || (mazeData[currentRow + 1][currentColumn] == 'F')) {
          // It can move DOWN
          minStepsReachHere = calculateDistanceWhenMovingInMaze(currentRow, currentColumn, currentRow + 1, currentColumn, numOfStepsReachHere + 1, minStepsReachHere);
        }
      }
      
      // Try LEFT direction
      if (fromDirection != LEFT) {
        if ((trackMazeData[currentRow][currentColumn - 1] == ' ') || (mazeData[currentRow][currentColumn - 1] == 'F')) {
          // It can move LEFT
          minStepsReachHere = calculateDistanceWhenMovingInMaze(currentRow, currentColumn, currentRow, currentColumn - 1, numOfStepsReachHere + 1, minStepsReachHere);
        }
      }
      
      // Try RIGHT direction
      if (fromDirection != RIGHT) {
        if ((trackMazeData[currentRow][currentColumn + 1] == ' ') || (mazeData[currentRow][currentColumn + 1] == 'F')) {
          // It can move RIGHT
          minStepsReachHere = calculateDistanceWhenMovingInMaze(currentRow, currentColumn, currentRow, currentColumn + 1, numOfStepsReachHere + 1, minStepsReachHere);
        }
      }
      
      trackMazeData[currentRow][currentColumn] = ' ';
      return minStepsReachHere;
    }
  }
  
  /**
   * copyMaze
   * A utility method for copying maze data. It is also used for backing up and restoring maze data.
   * @param originalMaze char 2D array maze is sent in to be replicated.
   * @return char[][] the exact copy of the original maze.
   */
  public static char[][] copyMaze(char[][] originalMaze) {
    char[][] newMaze = new char[originalMaze.length][originalMaze[0].length];
    for (int i = 0; i < originalMaze.length; i++) {
      for (int j = 0; j < originalMaze[0].length; j++) {
        newMaze[i][j] = originalMaze[i][j];
      }
    }
    return newMaze;
  }
  
  /**
   * readMazeFile
   * method used to read and copy maze data into a char[][] 
   * @param fileName this is the name of the maze file where the user inputs from the main method
   * @return char[][] the 2D array that stores the maze.
   * @throws Exception when an error occurs during reading the file.
   */
  public static char[][] readMazeFile(String fileName) throws Exception {
    
    File file = new File(fileName);
    Scanner input = new Scanner(file);
    String firstLine = input.nextLine();
    String line = "";
    int arraySize = firstLine.length();
    char[][] mazeData = new char[arraySize][arraySize];

    for (int column = 0; column < arraySize; column++) {
      mazeData[0][column] = firstLine.charAt(column);
    }
    
    for (int row = 1; row < arraySize; row++) {
      line = input.nextLine();
      for (int column = 0; column < arraySize; column++) {
        mazeData[row][column] = line.charAt(column);
      }
    }
    input.close();
    return mazeData;
  }
   
  /**
   * outputln
   * Outputs the string to the text file on a new line
   * @param outputInfo string that contains info needed to be output (eg. trap-coordinates)
   */
  public static void outputln(String outputInfo) {
    printWriter.println(outputInfo);
  }
  
  /**
   * outputMaze
   * Outputs the maze to the text file
   * @param mazeData the char[][] that has the maze stored in it  
   */
  public static void outputMaze(char[][] mazeData) {
    for (char[] row : mazeData) {
      for (char cell : row) {
        outputChar(cell);
      }
      outputln ( "" );
    }    
  }
  
  /**
   * outputChar
   * Outputs the character to the text file. This method is used by outputMaze() to output each cell
   * @param character char variable that stores a character in each maze cell that needs to be output by outputMaze()
   */
  public static void outputChar(char character) {
    printWriter.print(character);
  }
}
